export interface DishOption {
  id: string;
  nameTh: string;
  nameEn: string;
  price: number;
}

export interface MenuItem {
  id: string;
  nameTh: string;
  nameEn: string;
  category: 'curry_soup' | 'wok_fry' | 'salad_appetizer' | 'rice_noodle' | 'dessert_drink';
  price: number;
  spiceLevel: 0 | 1 | 2 | 3; // 0=ไม่เผ็ด, 1=เผ็ดน้อย, 2=เผ็ดกลาง, 3=เผ็ดจัดจ้าน
  descriptionTh: string;
  descriptionEn: string;
  image?: string;
  tag?: string;
  dietary?: string[];
  prepTimeMinutes: number;
  calories?: number;
  availableOptions?: DishOption[];
}

export const CATEGORIES = [
  { id: 'all', nameTh: 'ทั้งหมด', nameEn: 'All Dishes' },
  { id: 'curry_soup', nameTh: 'แกงและต้ม', nameEn: 'Curries & Soups' },
  { id: 'wok_fry', nameTh: 'จานผัดและทอด', nameEn: 'Wok & Crispy' },
  { id: 'salad_appetizer', nameTh: 'ยำและทานเล่น', nameEn: 'Salads & Starters' },
  { id: 'rice_noodle', nameTh: 'สำรับข้าวและเส้น', nameEn: 'Rice & Noodles' },
  { id: 'dessert_drink', nameTh: 'ของหวานและเครื่องดื่ม', nameEn: 'Desserts & Drinks' },
] as const;

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'tomyum-goong',
    nameTh: 'ต้มยำกุ้งแม่น้ำโบราณ',
    nameEn: 'Signature River Prawn Tom Yum',
    category: 'curry_soup',
    price: 390,
    spiceLevel: 3,
    descriptionTh: 'กุ้งแม่น้ำตัวโตคัดพิเศษ ต้มในน้ำซุปสมุนไพรสด ข่า ตะไคร้ ใบมะกรูด และมันกุ้งเคี่ยวเข้มข้น หอมพริกเผาเผาเองและมะนาวแท้แป้นรำไพ',
    descriptionEn: 'Colossal river prawns simmered in an aromatic broth infused with fresh galangal, lemongrass, kaffir lime, and roasted chili oil.',
    image: '/src/assets/images/dish_tomyum_prawn_1792980143832.jpg',
    tag: 'สูตรชาววังซิกเนเจอร์',
    dietary: ['อาหารทะเล', 'ปลอดผงชูรส'],
    prepTimeMinutes: 15,
    calories: 320,
    availableOptions: [
      { id: 'extra-prawn', nameTh: 'เพิ่มกุ้งแม่น้ำ 1 ตัว', nameEn: 'Extra River Prawn', price: 160 },
      { id: 'mushrooms', nameTh: 'เพิ่มเห็ดฟางสด', nameEn: 'Extra Straw Mushrooms', price: 30 },
      { id: 'extra-rice', nameTh: 'ข้าวหอมมะลิอุบลแท้', nameEn: 'Jasmine Rice Bowl', price: 25 },
    ]
  },
  {
    id: 'massaman-beef',
    nameTh: 'แกงมัสมั่นเนื้อน่องลายตุ๋นเตาถ่าน',
    nameEn: 'Slow-Cooked Beef Shank Massaman Curry',
    category: 'curry_soup',
    price: 380,
    spiceLevel: 1,
    descriptionTh: 'เนื้อน่องลายคัดเกรด ตุ๋นด้วยเตาถ่านนานกว่า 6 ชั่วโมงจนนุ่มละลายในปาก คลุกเคล้าเครื่องแกงมัสมั่นโขลกเอง ถั่วลิสงคั่วใหม่ หอมแดง และแท่งอบเชย',
    descriptionEn: 'Tender beef shank braised over charcoal for 6 hours in rich coconut curry with roasted whole peanuts, shallots, and cinnamon.',
    image: '/src/assets/images/dish_massaman_beef_1792980144159.jpg',
    tag: 'ยอดนิยมระดับโลก',
    dietary: ['เนื้อวัว', 'ถั่วลิสง'],
    prepTimeMinutes: 12,
    calories: 540,
    availableOptions: [
      { id: 'extra-roti', nameTh: 'โรตีกรอบสูตรโบราณ (2 แผ่น)', nameEn: 'Crispy Roti (2 pcs)', price: 50 },
      { id: 'extra-meat', nameTh: 'เพิ่มเนื้อน่องลายพิเศษ', nameEn: 'Extra Beef Shank', price: 120 },
      { id: 'extra-rice', nameTh: 'ข้าวหอมมะลิอุบลแท้', nameEn: 'Jasmine Rice Bowl', price: 25 },
    ]
  },
  {
    id: 'green-curry-chicken',
    nameTh: 'แกงเขียวหวานไก่บ้านยอดมะพร้าวอ่อน',
    nameEn: 'Heritage Green Curry with Free-Range Chicken',
    category: 'curry_soup',
    price: 260,
    spiceLevel: 2,
    descriptionTh: 'พริกแกงเขียวหวานตำสดจากพริกขี้หนูสวนสด กะทิคั้นสดแท้ ยอดมะพร้าวอ่อนกรอบหวาน และไก่บ้านเนื้อแน่นเคี้ยวเพลิน หอมใบโหระพา',
    descriptionEn: 'House-pounded green chili paste with fresh pressed coconut milk, young coconut shoots, and free-range chicken topped with sweet Thai basil.',
    tag: 'รสมือคุณยาย',
    dietary: ['เนื้อไก่', 'ปราศจากกลูเตน'],
    prepTimeMinutes: 14,
    calories: 410,
    availableOptions: [
      { id: 'khanom-chin', nameTh: 'ขนมจีนเส้นสดแป้งหมัก', nameEn: 'Fresh Rice Noodles', price: 35 },
      { id: 'salted-egg', nameTh: 'ไข่เค็มไชยาอบควัน', nameEn: 'Salted Duck Egg', price: 25 },
    ]
  },
  {
    id: 'tom-kha-gai',
    nameTh: 'ต้มข่าไก่ใส่หัวปลีสวนอินทรีย์',
    nameEn: 'Silky Coconut Galangal Soup with Chicken & Banana Blossom',
    category: 'curry_soup',
    price: 240,
    spiceLevel: 1,
    descriptionTh: 'น้ำซุปกะทิสดเนียนนุ่ม หอมกรุ่นกลิ่นข่าอ่อนและตะไคร้ รสกลมกล่อมเปรี้ยวละมุนจากมะนาวสดแท้ หัวปลีอินทรีย์สดจากสวนราชบุรี',
    descriptionEn: 'Silky coconut soup infused with young galangal, lemongrass, tender chicken slices, and organic wild banana blossom.',
    dietary: ['เนื้อไก่'],
    prepTimeMinutes: 12,
    calories: 360,
    availableOptions: [
      { id: 'extra-rice', nameTh: 'ข้าวหอมมะลิอุบลแท้', nameEn: 'Jasmine Rice Bowl', price: 25 },
    ]
  },
  {
    id: 'pad-thai-kung',
    nameTh: 'ผัดไทยกุ้งแม่น้ำห่อไข่โบราณ',
    nameEn: 'Traditional Egg-Wrapped Pad Thai with Giant River Prawns',
    category: 'wok_fry',
    price: 320,
    spiceLevel: 1,
    descriptionTh: 'เส้นจันท์เหนียวนุ่ม ผัดเคล้าน้ำซอสมะขามเปียกเคี่ยวโบราณ กุ้งแห้งตัวโต หัวไชโป๊วหวาน ห่อด้วยไข่เป็ดบางกรอบ พร้อมกุ้งแม่น้ำย่างหอมกรุ่น',
    descriptionEn: 'Chewy Chantaburi noodles wok-tossed in homemade tamarind reduction, wrapped in golden crepe lace, served with roasted river prawns.',
    tag: 'เชฟแนะนำ',
    dietary: ['อาหารทะเล', 'ถั่วลิสง'],
    prepTimeMinutes: 15,
    calories: 480,
    availableOptions: [
      { id: 'extra-shrimp', nameTh: 'เพิ่มกุ้งแม่น้ำย่าง', nameEn: 'Extra Grilled Prawn', price: 140 },
      { id: 'crispy-wonton', nameTh: 'เกี๊ยวกรอบเคียงผัดไทย', nameEn: 'Crispy Wonton Strips', price: 30 },
    ]
  },
  {
    id: 'seabass-fishsauce',
    nameTh: 'ปลากะพงทอดน้ำปลาแท้ คู่ยำมะม่วงน้ำดอกไม้',
    nameEn: 'Deep-Fried Whole Sea Bass in Premium Fish Sauce & Green Mango Salad',
    category: 'wok_fry',
    price: 490,
    spiceLevel: 2,
    descriptionTh: 'ปลากะพงสดจากทะเลบางปะกง ทอดจนสีเหลืองทองกรอบนอกเนื้อในชุ่มฉ่ำ ราดซอสน้ำปลาแท้เมืองระยองเคี่ยวคาราเมล เคียงยำมะม่วงรสจัดจ้าน',
    descriptionEn: 'Crispy golden whole sea bass glazed with caramelized Rayong fish sauce, served with refreshing spicy green mango salad.',
    tag: 'จานโปรดครอบครัว',
    dietary: ['ปลาทะเล'],
    prepTimeMinutes: 20,
    calories: 620,
    availableOptions: [
      { id: 'extra-mango-salad', nameTh: 'เพิ่มยำมะม่วง 1 ถ้วย', nameEn: 'Extra Mango Salad', price: 65 },
    ]
  },
  {
    id: 'wagyu-basil',
    nameTh: 'ผัดกะเพราเนื้อวากิวสับใบกะเพราป่า ไข่ดาวเป็ดกรอบ',
    nameEn: 'Wagyu Beef Holy Basil Stir-Fry with Crispy Duck Egg',
    category: 'wok_fry',
    price: 340,
    spiceLevel: 3,
    descriptionTh: 'เนื้อวากิวคัดเกรดสับหยาบ ผัดคั่วไฟแรงด้วยใบกะเพราป่ากลิ่นหอมแรง พริกขี้หนูสวนและกระเทียมไทย เสิร์ฟพร้อมไข่ดาวเป็ดไข่แดงเยิ้มขอบกรอบฟู',
    descriptionEn: 'Minced premium Wagyu beef flash-wok fried with pungent wild holy basil, bird\'s eye chili, and garlic, crowned with a crispy duck egg.',
    tag: 'รสจัดจ้านไฟลุก',
    dietary: ['เนื้อวัว', 'เผ็ดแท้'],
    prepTimeMinutes: 10,
    calories: 520,
    availableOptions: [
      { id: 'extra-duck-egg', nameTh: 'เพิ่มไข่ดาวเป็ดกรอบ', nameEn: 'Extra Crispy Duck Egg', price: 25 },
      { id: 'extra-wagyu', nameTh: 'เพิ่มเนื้อวากิวพิเศษ 50g', nameEn: 'Extra Wagyu 50g', price: 110 },
      { id: 'extra-rice', nameTh: 'ข้าวหอมมะลิอุบลแท้', nameEn: 'Jasmine Rice Bowl', price: 25 },
    ]
  },
  {
    id: 'crab-curry-powder',
    nameTh: 'ปูนิ่มทอดกรอบผัดผงกะหรี่ไข่นุ่ม',
    nameEn: 'Crispy Soft Shell Crab Stir-Fried with Golden Curry Cream',
    category: 'wok_fry',
    price: 420,
    spiceLevel: 1,
    descriptionTh: 'ปูนิ่มสดทอดจนกรอบสะท้าน คลุกเคล้าซอสผงกะหรี่หอมละมุน นมสด และไข่ไก่อินทรีย์เนื้อเนียนนุ่มลิ้น รสชาติกลมกล่อม',
    descriptionEn: 'Deep-fried crispy whole soft shell crab enveloped in fragrant turmeric yellow curry sauce, silky eggs, and scallions.',
    dietary: ['อาหารทะเล'],
    prepTimeMinutes: 16,
    calories: 470,
    availableOptions: [
      { id: 'extra-crab', nameTh: 'เพิ่มปูนิ่ม 1 ตัว', nameEn: 'Extra Soft Shell Crab', price: 160 },
      { id: 'extra-rice', nameTh: 'ข้าวหอมมะลิอุบลแท้', nameEn: 'Jasmine Rice Bowl', price: 25 },
    ]
  },
  {
    id: 'somtum-riverprawn',
    nameTh: 'ส้มตำไทยกุ้งแม่น้ำย่างถ่าน',
    nameEn: 'Royal Som Tum Papaya Salad with Charcoal-Grilled Prawn',
    category: 'salad_appetizer',
    price: 280,
    spiceLevel: 2,
    descriptionTh: 'มะละกอสับเส้นสดตำครกดินเผา รสเปรี้ยวหวานเค็มครบรส มะเขือเทศสีดา กุ้งแห้งเกรดเอ ถั่วลิสงคั่วเอง เสิร์ฟเคียงกุ้งแม่น้ำย่างถ่านหอมเตา',
    descriptionEn: 'Crisp hand-shredded green papaya pounded in earthen mortar with lime juice, palm sugar, tamarind, and whole charcoal-grilled river prawn.',
    tag: 'แซ่บกลมกล่อม',
    dietary: ['อาหารทะเล', 'ถั่วลิสง'],
    prepTimeMinutes: 10,
    calories: 280,
    availableOptions: [
      { id: 'salted-egg', nameTh: 'เพิ่มไข่เค็มไชยาแท้', nameEn: 'Add Salted Duck Egg', price: 25 },
      { id: 'sticky-rice', nameTh: 'ข้าวเหนียวเขี้ยวงูหอมนุ่ม', nameEn: 'Steamed Sticky Rice', price: 30 },
    ]
  },
  {
    id: 'pomelo-salad',
    nameTh: 'ยำส้มโอทับทิมสยามกุ้งสดมะพร้าวคั่ว',
    nameEn: 'Siamese Ruby Pomelo Salad with Fresh Prawns & Toasted Coconut',
    category: 'salad_appetizer',
    price: 290,
    spiceLevel: 1,
    descriptionTh: 'ส้มโอพันธุ์ทับทิมสยามหวานอมเปรี้ยว คลุกเคล้าน้ำยำน้ำพริกเผาเคี่ยวโบราณ กุ้งแชบ๊วยลวกสุกกำลังดี โรยมะพร้าวคั่วทองและหอมเจียวกรอบ',
    descriptionEn: 'Juicy ruby pomelo tossed with sweet-tart roasted chili dressing, poached tiger prawns, golden toasted coconut flakes, and crispy shallots.',
    tag: 'ตำรับอาหารว่างชาววัง',
    dietary: ['อาหารทะเล'],
    prepTimeMinutes: 12,
    calories: 220,
  },
  {
    id: 'tod-mun-goong',
    nameTh: 'ทอดมันกุ้งใบชะพลูน้ำจิ้มบ๊วยเจี่ย',
    nameEn: 'Handcrafted Crispy Shrimp Cakes with Plum Sauce',
    category: 'salad_appetizer',
    price: 250,
    spiceLevel: 0,
    descriptionTh: 'เนื้อกุ้งสดล้วน 100% นวดจนเหนียวนุ่มเด้ง ปั้นคลุกเกล็ดขนมปังสด ทอดใหม่ๆ ทุกจาน กรอบนอกเด้งใน จิ้มคู่น้ำจิ้มบ๊วยสูตรพิเศษของเรือนรสไทย',
    descriptionEn: 'Golden crispy handcrafted patties made of 100% fresh minced prawns, served piping hot with sweet spiced wild plum sauce.',
    dietary: ['อาหารทะเล'],
    prepTimeMinutes: 12,
    calories: 340,
  },
  {
    id: 'pork-satay',
    nameTh: 'หมูสะเต๊ะเตาถ่านกะทิสด (10 ไม้)',
    nameEn: 'Charcoal Pork Satay with Achar Relish & Peanut Sauce (10 Skewers)',
    category: 'salad_appetizer',
    price: 220,
    spiceLevel: 0,
    descriptionTh: 'เนื้อสันในหมูหมักสมุนไพรและนมสดจนนุ่ม ย่างบนเตาถ่านพรมหัวกะทิตลอดเวลา เสิร์ฟคู่น้ำจิ้มถั่วบดละเอียดเข้มข้นและอาจาดแตงกวา',
    descriptionEn: 'Tender pork tenderloin marinated in turmeric coconut milk, charcoal-grilled and paired with rich peanut curry sauce and crisp cucumber achar.',
    tag: 'นุ่มละมุนเตาถ่าน',
    dietary: ['เนื้อหมู', 'ถั่วลิสง'],
    prepTimeMinutes: 12,
    calories: 410,
    availableOptions: [
      { id: 'toast', nameTh: 'ขนมปังปิ้งเตาถ่าน (2 แผ่น)', nameEn: 'Charcoal Grilled Toast', price: 30 },
      { id: 'extra-satay-5', nameTh: 'เพิ่มสะเต๊ะ 5 ไม้', nameEn: 'Add 5 Skewers', price: 95 },
    ]
  },
  {
    id: 'pineapple-fried-rice',
    nameTh: 'ข้าวผัดสับปะรดภูแลกุ้งลายเสือหมูหยอง',
    nameEn: 'Phulae Pineapple Fried Rice with Tiger Prawns & Floss',
    category: 'rice_noodle',
    price: 330,
    spiceLevel: 0,
    descriptionTh: 'ข้าวหอมมะลิผัดเมล็ดร่วนกับผงกะหรี่หอม ลูกเกด เม็ดมะม่วงหิมพานต์ และเนื้อสับปะรดภูแลหวานฉ่ำ เสิร์ฟในผลสับปะรดผ่าซีก โรยหมูหยองกรอบ',
    descriptionEn: 'Fragrant jasmine rice wok-fried with mild aromatic spices, juicy Phulae pineapple chunks, tiger prawns, toasted cashews, and pork floss.',
    tag: 'เสิร์ฟในผลสับปะรด',
    dietary: ['อาหารทะเล', 'ถั่ว'],
    prepTimeMinutes: 16,
    calories: 580,
  },
  {
    id: 'khao-soi-kai',
    nameTh: 'ข้าวซอยไก่เมืองเหนือสูตรเชียงใหม่โบราณ',
    nameEn: 'Northern Thai Chiang Mai Khao Soi with Braised Chicken Drumstick',
    category: 'rice_noodle',
    price: 250,
    spiceLevel: 2,
    descriptionTh: 'บะหมี่ไข่เส้นแบนในน้ำแกงกะทิเข้มข้นกลิ่นเครื่องเทศเมืองเหนือ น่องไก่ชิ้นโตตุ๋นจนร่อน โรยบะหมี่กรอบ เสิร์ฟพร้อมผักกาดดอง หอมแดง และพริกผัดน้ำมัน',
    descriptionEn: 'Flat egg noodles in a rich Northern curry broth with slow-cooked drumstick, topped with crispy egg ribbons, pickled mustard greens, and lime.',
    tag: 'ต้นตำรับล้านนา',
    dietary: ['เนื้อไก่'],
    prepTimeMinutes: 12,
    calories: 490,
  },
  {
    id: 'mango-sticky-rice',
    nameTh: 'ข้าวเหนียวมะม่วงน้ำดอกไม้ อัญชันกะทิสด',
    nameEn: 'Golden Nam Dok Mai Mango with Butterfly Pea Sticky Rice',
    category: 'dessert_drink',
    price: 190,
    spiceLevel: 0,
    descriptionTh: 'มะม่วงน้ำดอกไม้สุกสีทองหวานฉ่ำ ไร้เสี้ยน เคียงคู่ข้าวเหนียวมูนกะทิสดหอมอบควันเทียน ย้อมสีฟ้าธรรมชาติจากดอกอัญชัน โรยถั่วทองคั่วกรอบ',
    descriptionEn: 'Sweet ripe Nam Dok Mai mango served with coconut sticky rice tinted naturally by organic butterfly pea flowers, topped with warm salted coconut cream.',
    image: '/src/assets/images/dish_mango_stickyrice_1792980144038.jpg',
    tag: 'ของหวานยอดนิยมอันดับ 1',
    dietary: ['มังสวิรัติ', 'ปราศจากกลูเตน'],
    prepTimeMinutes: 8,
    calories: 380,
  },
  {
    id: 'tub-tim-krob',
    nameTh: 'ทับทิมกรอบชาววัง กะทิสดอบควันเทียน',
    nameEn: 'Royal Tub Tim Krob (Water Chestnut Rubies in Smoked Coconut Milk)',
    category: 'dessert_drink',
    price: 140,
    spiceLevel: 0,
    descriptionTh: 'แห้วกรอบคลุกแป้งมันสำปะหลังย้อมสีแดงสดจากน้ำฝาง เคี้ยวกรุบกรอบ ในน้ำกะทิสดเคี่ยวกับน้ำตาลโตนดแท้ อบควันเทียนหอมจรุงใจ พร้อมเนื้อมะพร้าวกะทิ',
    descriptionEn: 'Crisp water chestnut jewels coated in translucent tapioca pearls, floating in candle-smoked coconut milk with crushed ice and tender coconut meat.',
    dietary: ['มังสวิรัติ'],
    prepTimeMinutes: 6,
    calories: 260,
  },
  {
    id: 'royal-thai-tea',
    nameTh: 'ชาไทยโบราณพรีเมียม ฟองนมนุ่ม',
    nameEn: 'Signature Thai Iced Milk Tea with Velvety Foam',
    category: 'dessert_drink',
    price: 110,
    spiceLevel: 0,
    descriptionTh: 'ใบชาแดงไทยคั่วพิเศษเบลนด์ 3 แหล่งปลูก ชงสกัดเข้มข้น หอมกลิ่นกระดังงาและวานิลลา นมข้นหวานคุณภาพดี ท็อปด้วยฟองนมนุ่มละมุน',
    descriptionEn: 'Hand-pulled rich Ceylon black tea leaves infused with star anise and aromatic spices, sweetened with condensed milk and creamy cold foam.',
    dietary: ['มังสวิรัติ'],
    prepTimeMinutes: 5,
    calories: 210,
  },
  {
    id: 'butterfly-pea-honey-lime',
    nameTh: 'น้ำอัญชันมะนาวน้ำผึ้งป่าเดือนห้า',
    nameEn: 'Butterfly Pea Wild Honey Lime Elixir',
    category: 'dessert_drink',
    price: 110,
    spiceLevel: 0,
    descriptionTh: 'ดอกอัญชันออร์แกนิกสกัดสด เปลี่ยนสีเป็นม่วงประกายสดใสเมื่อบีบมะนาวแป้นสดแท้ ผสมน้ำผึ้งป่าเดือนห้าแท้ หวานอมเปรี้ยว สดชื่นดับกระหาย',
    descriptionEn: 'Fresh steeped blue butterfly pea blossoms magically shifting violet with fresh squeezed lime juice, sweetened with organic wild forest honey.',
    dietary: ['มังสวิรัติ', 'เพื่อสุขภาพ'],
    prepTimeMinutes: 5,
    calories: 120,
  }
];

export interface CartItem {
  id: string; // unique cart entry ID
  menuItem: MenuItem;
  quantity: number;
  selectedSpiceLevel: number;
  selectedOptions: DishOption[];
  specialInstructions?: string;
}

export interface TableBooking {
  bookingId: string;
  name: string;
  phone: string;
  date: string;
  timeSlot: string;
  guestCount: number;
  seatingArea: 'indoor_thai_hall' | 'garden_patio' | 'lotus_pond_balcony';
  specialOccasion?: string;
  createdAt: string;
}
