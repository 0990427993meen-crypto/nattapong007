import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { DishCustomizeModal } from './components/DishCustomizeModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { ReservationModal } from './components/ReservationModal';
import { HeritageSection } from './components/HeritageSection';
import { Footer } from './components/Footer';
import { MenuItem, CartItem } from './data/menuData';
import { ShoppingBag, Check } from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<'th' | 'en'>('th');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReservationOpen, setIsReservationOpen] = useState(false);
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Completed order state for modal
  const [lastOrder, setLastOrder] = useState<{
    orderNumber: string;
    items: CartItem[];
    grandTotal: number;
    serviceType: 'dine_in' | 'takeaway';
    tableNumber?: string;
    customerName?: string;
  } | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  const handleAddToCart = (newItem: CartItem) => {
    setCartItems((prev) => {
      // Check if identical item (same dish, spice, options, and note) exists
      const existingIndex = prev.findIndex(
        (i) =>
          i.menuItem.id === newItem.menuItem.id &&
          i.selectedSpiceLevel === newItem.selectedSpiceLevel &&
          i.specialInstructions === newItem.specialInstructions &&
          JSON.stringify(i.selectedOptions) === JSON.stringify(newItem.selectedOptions)
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += newItem.quantity;
        return updated;
      }
      return [...prev, newItem];
    });

    const dishName = language === 'th' ? newItem.menuItem.nameTh : newItem.menuItem.nameEn;
    showToast(
      language === 'th'
        ? `เพิ่ม "${dishName}" ลงในสำรับแล้ว`
        : `Added "${dishName}" to order`
    );
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleCheckout = (orderData: {
    serviceType: 'dine_in' | 'takeaway';
    tableNumber?: string;
    customerName: string;
    customerPhone: string;
    deliveryAddress?: string;
    discountAmount: number;
    subtotal: number;
    grandTotal: number;
  }) => {
    const orderNumber = `RR-${Math.floor(1000 + Math.random() * 9000)}`;
    setLastOrder({
      orderNumber,
      items: [...cartItems],
      grandTotal: orderData.grandTotal,
      serviceType: orderData.serviceType,
      tableNumber: orderData.tableNumber,
      customerName: orderData.customerName,
    });
    setCartItems([]);
    setIsCartOpen(false);
  };

  const totalCartCount = cartItems.reduce((acc, i) => acc + i.quantity, 0);

  const scrollToMenu = () => {
    const menuEl = document.getElementById('menu');
    if (menuEl) {
      menuEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] font-thai-body text-[#292524]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 right-4 sm:right-8 z-50 bg-[#2B1B17] text-white px-4 py-2.5 rounded-xl shadow-lg border border-[#8C2C1D] flex items-center gap-2.5 text-xs sm:text-sm animate-bounce-subtle">
          <div className="w-5 h-5 rounded-full bg-[#8C2C1D] flex items-center justify-center text-white">
            <Check className="w-3.5 h-3.5" />
          </div>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <Header
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenReservation={() => setIsReservationOpen(true)}
        language={language}
        onToggleLanguage={() => setLanguage((prev) => (prev === 'th' ? 'en' : 'th'))}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          language={language}
          onScrollToMenu={scrollToMenu}
          onOpenReservation={() => setIsReservationOpen(true)}
        />

        {/* Menu & Ordering Section */}
        <MenuSection
          language={language}
          onSelectDish={(item) => setSelectedDish(item)}
        />

        {/* Heritage & Cooking Lineage */}
        <HeritageSection language={language} />
      </main>

      {/* Footer */}
      <Footer language={language} />

      {/* Floating Mobile Cart Bar (when items in cart) */}
      {totalCartCount > 0 && !isCartOpen && (
        <div className="fixed bottom-4 left-4 right-4 md:hidden z-30">
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full py-3.5 px-5 bg-[#8C2C1D] text-white rounded-xl shadow-xl flex items-center justify-between font-bold text-sm active:scale-[0.99] border border-[#A63524]"
          >
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#FCD34D]" />
              <span>{language === 'th' ? 'ดูสำรับที่สั่ง' : 'View Order'}</span>
              <span className="px-2 py-0.5 rounded-full bg-black/30 text-xs tabular-nums">
                {totalCartCount}
              </span>
            </div>
            <span className="font-mono tabular-nums text-xs sm:text-sm text-[#FCD34D]">
              ฿{cartItems.reduce((acc, i) => acc + (i.menuItem.price + i.selectedOptions.reduce((s, o) => s + o.price, 0)) * i.quantity, 0).toLocaleString()}
            </span>
          </button>
        </div>
      )}

      {/* Modals & Drawers */}
      <DishCustomizeModal
        item={selectedDish}
        language={language}
        onClose={() => setSelectedDish(null)}
        onAddToCart={handleAddToCart}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        language={language}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />

      {lastOrder && (
        <OrderSuccessModal
          isOpen={!!lastOrder}
          onClose={() => setLastOrder(null)}
          orderNumber={lastOrder.orderNumber}
          items={lastOrder.items}
          grandTotal={lastOrder.grandTotal}
          serviceType={lastOrder.serviceType}
          tableNumber={lastOrder.tableNumber}
          customerName={lastOrder.customerName}
          language={language}
        />
      )}

      <ReservationModal
        isOpen={isReservationOpen}
        onClose={() => setIsReservationOpen(false)}
        language={language}
      />
    </div>
  );
}
