import React from 'react';
import { MapPin, Phone, Clock, Mail, UtensilsCrossed } from 'lucide-react';

interface FooterProps {
  language: 'th' | 'en';
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  return (
    <footer id="location" className="bg-[#241A16] text-[#E5DCD1] pt-16 pb-12 border-t border-[#3B2D26]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand Info */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#8C2C1D] flex items-center justify-center text-[#F5E6CC]">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xl font-bold font-thai-title text-white">
                  {language === 'th' ? 'เรือนรสไทย' : 'Ruen Ros Thai'}
                </span>
                <span className="block text-[10px] tracking-widest uppercase text-[#BFA082] font-display">
                  Heritage Thai Cuisine
                </span>
              </div>
            </div>
            <p className="text-xs text-[#BFAFA2] font-thai-body leading-relaxed">
              {language === 'th'
                ? 'ร้านอาหารไทยดั้งเดิมบรรยากาศเรือนไม้สักริมสายน้ำ สืบสานตำรับอาหารชาววังแท้ด้วยใจรักในมรดกอาหารไทย'
                : 'Authentic royal Siamese gastronomy served in a tranquil riverside teakwood manor.'}
            </p>
          </div>

          {/* Location & Address */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#E8CBA3] font-thai-title">
              {language === 'th' ? 'ที่ตั้งร้าน' : 'Location'}
            </h4>
            <div className="flex items-start gap-2.5 text-xs text-[#BFAFA2] leading-relaxed">
              <MapPin className="w-4 h-4 text-[#C27E47] shrink-0 mt-0.5" />
              <span>
                {language === 'th'
                  ? 'เลขที่ 88 ถนนพระอาทิตย์ แขวงชนะสงคราม เขตพระนคร กรุงเทพมหานคร 10200 (มีที่จอดรถสะดวก)'
                  : '88 Phra Athit Road, Chana Songkhram, Phra Nakhon, Bangkok 10200'}
              </span>
            </div>
          </div>

          {/* Opening Hours */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#E8CBA3] font-thai-title">
              {language === 'th' ? 'เวลาให้บริการ' : 'Opening Hours'}
            </h4>
            <div className="flex items-start gap-2.5 text-xs text-[#BFAFA2] leading-relaxed">
              <Clock className="w-4 h-4 text-[#C27E47] shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white">
                  {language === 'th' ? 'เปิดบริการทุกวัน (จันทร์ - อาทิตย์)' : 'Open Daily'}
                </p>
                <p className="text-[#A8988B] mt-0.5">
                  {language === 'th' ? 'มื้อกลางวัน: 11:00 - 15:00 น.' : 'Lunch: 11:00 AM - 3:00 PM'}
                </p>
                <p className="text-[#A8988B]">
                  {language === 'th' ? 'มื้อค่ำ: 17:00 - 22:00 น.' : 'Dinner: 5:00 PM - 10:00 PM'}
                </p>
              </div>
            </div>
          </div>

          {/* Contact & Inquiries */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#E8CBA3] font-thai-title">
              {language === 'th' ? 'ติดต่อและสำรองที่นั่ง' : 'Reservations & Inquiry'}
            </h4>
            <div className="space-y-2 text-xs text-[#BFAFA2]">
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#C27E47]" />
                <span className="font-mono text-white font-medium">02-281-9988 / 081-456-7890</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#C27E47]" />
                <span>contact@ruenrosthai.com</span>
              </div>
              <p className="text-[11px] text-[#A8988B] pt-1">
                LINE Official: <span className="text-[#E8CBA3]">@ruenrosthai</span>
              </p>
            </div>
          </div>
        </div>

        {/* Clean Bottom Copyright Bar */}
        <div className="pt-8 border-t border-[#3B2D26] flex flex-col sm:flex-row items-center justify-between text-xs text-[#8A796F] gap-4">
          <p>© {new Date().getFullYear()} เรือนรสไทย (Ruen Ros Thai). สงวนลิขสิทธิ์ทุกประการ.</p>
          <div className="flex items-center gap-6">
            <a href="#menu" className="hover:text-white transition-colors">
              {language === 'th' ? 'เมนูอาหาร' : 'Menus'}
            </a>
            <a href="#heritage" className="hover:text-white transition-colors">
              {language === 'th' ? 'เกี่ยวกับเรา' : 'About'}
            </a>
            <a href="#location" className="hover:text-white transition-colors">
              {language === 'th' ? 'นโยบายความเป็นส่วนตัว' : 'Privacy'}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
