import React, { useState } from 'react';
import { CartItem } from '../data/menuData';
import { X, Trash2, Plus, Minus, ShoppingBag, UtensilsCrossed, Bike, Tag, ArrowRight } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  language: 'th' | 'en';
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: (orderData: {
    serviceType: 'dine_in' | 'takeaway';
    tableNumber?: string;
    customerName: string;
    customerPhone: string;
    deliveryAddress?: string;
    discountAmount: number;
    subtotal: number;
    grandTotal: number;
  }) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  language,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}) => {
  const [serviceType, setServiceType] = useState<'dine_in' | 'takeaway'>('dine_in');
  const [tableNumber, setTableNumber] = useState<string>('โต๊ะ 04 (ริมสระบัว)');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [deliveryAddress, setDeliveryAddress] = useState<string>('');
  const [couponCode, setCouponCode] = useState<string>('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);
  const [couponError, setCouponError] = useState<string>('');

  if (!isOpen) return null;

  // Calculate Subtotal
  const subtotal = cartItems.reduce((acc, item) => {
    const addonsCost = item.selectedOptions.reduce((s, o) => s + o.price, 0);
    return acc + (item.menuItem.price + addonsCost) * item.quantity;
  }, 0);

  const handleApplyCoupon = () => {
    const code = couponCode.trim().toUpperCase();
    if (code === 'RUEN10' || code === 'THAI10') {
      const discount = Math.round(subtotal * 0.1);
      setAppliedDiscount(discount);
      setCouponError('');
    } else if (code === 'VIP50') {
      setAppliedDiscount(Math.min(50, subtotal));
      setCouponError('');
    } else {
      setCouponError(language === 'th' ? 'รหัสคูปองไม่ถูกต้อง (ลอง RUEN10)' : 'Invalid code (try RUEN10)');
    }
  };

  const grandTotal = Math.max(0, subtotal - appliedDiscount);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (serviceType === 'takeaway' && (!customerName || !customerPhone)) {
      alert(language === 'th' ? 'กรุณาระบุชื่อและเบอร์โทรศัพท์สำหรับจัดส่ง' : 'Please provide your name and phone number');
      return;
    }
    onCheckout({
      serviceType,
      tableNumber: serviceType === 'dine_in' ? tableNumber : undefined,
      customerName: customerName || (language === 'th' ? 'ลูกค้าโต๊ะ ' + tableNumber : 'Dine-in Guest'),
      customerPhone,
      deliveryAddress,
      discountAmount: appliedDiscount,
      subtotal,
      grandTotal,
    });
  };

  const spiceLabels = {
    0: language === 'th' ? 'ไม่เผ็ด' : 'No spice',
    1: language === 'th' ? 'เผ็ดน้อย' : 'Mild',
    2: language === 'th' ? 'เผ็ดกลาง' : 'Medium',
    3: language === 'th' ? 'เผ็ดจัดจ้าน' : 'Spicy',
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs animate-fade-in">
      <div
        className="w-full max-w-md bg-[#FAF8F5] h-full shadow-2xl flex flex-col border-l border-[#E5DACD] text-[#2B1B17]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-[#E8DFD3] bg-[#F4EFE6] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#8C2C1D]" />
            <h3 className="text-base font-bold font-thai-title text-[#2B1B17]">
              {language === 'th' ? 'สำรับรายการที่เลือก' : 'Your Order Bag'}
            </h3>
            <span className="text-xs text-[#7A6759] font-medium tabular-nums">
              ({cartItems.length} {language === 'th' ? 'รายการ' : 'items'})
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#7A6759] hover:text-[#2B1B17] hover:bg-[#E5DACD]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Service Type Switch */}
        <div className="p-4 bg-[#EFE9DE] border-b border-[#E5DACD]">
          <div className="grid grid-cols-2 gap-2 p-1 bg-[#E4DDD0] rounded-xl text-xs font-semibold">
            <button
              type="button"
              onClick={() => setServiceType('dine_in')}
              className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                serviceType === 'dine_in'
                  ? 'bg-white text-[#8C2C1D] shadow-xs'
                  : 'text-[#695446] hover:text-[#2B1B17]'
              }`}
            >
              <UtensilsCrossed className="w-4 h-4" />
              <span>{language === 'th' ? 'ทานที่ร้าน' : 'Dine-In'}</span>
            </button>
            <button
              type="button"
              onClick={() => setServiceType('takeaway')}
              className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                serviceType === 'takeaway'
                  ? 'bg-white text-[#8C2C1D] shadow-xs'
                  : 'text-[#695446] hover:text-[#2B1B17]'
              }`}
            >
              <Bike className="w-4 h-4" />
              <span>{language === 'th' ? 'สั่งกลับ / ส่งถึงที่' : 'Takeaway'}</span>
            </button>
          </div>

          {/* Service Details */}
          {serviceType === 'dine_in' ? (
            <div className="mt-3 flex items-center justify-between text-xs text-[#594639]">
              <span>{language === 'th' ? 'หมายเลขโต๊ะของคุณ:' : 'Table Number:'}</span>
              <select
                value={tableNumber}
                onChange={(e) => setTableNumber(e.target.value)}
                className="bg-[#FAF8F5] border border-[#D5C9B7] rounded-lg px-2.5 py-1 text-xs font-semibold text-[#2B1B17]"
              >
                <option value="โต๊ะ 01 (ห้องแอร์เรือนใหญ่)">โต๊ะ 01 (ห้องแอร์เรือนใหญ่)</option>
                <option value="โต๊ะ 02 (ห้องแอร์เรือนใหญ่)">โต๊ะ 02 (ห้องแอร์เรือนใหญ่)</option>
                <option value="โต๊ะ 03 (ระเบียงไม้สัก)">โต๊ะ 03 (ระเบียงไม้สัก)</option>
                <option value="โต๊ะ 04 (ริมสระบัว)">โต๊ะ 04 (ริมสระบัว)</option>
                <option value="โต๊ะ 05 (ซุ้มร่มไม้)">โต๊ะ 05 (ซุ้มร่มไม้)</option>
              </select>
            </div>
          ) : (
            <div className="mt-3 space-y-2 text-xs">
              <input
                type="text"
                placeholder={language === 'th' ? 'ชื่อผู้สั่งอาหาร' : 'Customer Name'}
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-3 py-1.5 bg-[#FAF8F5] border border-[#D5C9B7] rounded-lg text-[#2B1B17]"
                required
              />
              <input
                type="tel"
                placeholder={language === 'th' ? 'เบอร์โทรศัพท์ติดต่อ' : 'Phone Number'}
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full px-3 py-1.5 bg-[#FAF8F5] border border-[#D5C9B7] rounded-lg text-[#2B1B17]"
                required
              />
              <input
                type="text"
                placeholder={language === 'th' ? 'ที่อยู่สำหรับจัดส่ง (ถ้าต้องการส่งถึงที่)' : 'Delivery Address'}
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                className="w-full px-3 py-1.5 bg-[#FAF8F5] border border-[#D5C9B7] rounded-lg text-[#2B1B17]"
              />
            </div>
          )}
        </div>

        {/* Scrollable Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cartItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-[#8C7667] space-y-3">
              <UtensilsCrossed className="w-12 h-12 opacity-30 text-[#8C2C1D]" />
              <p className="text-sm font-semibold font-thai-title text-[#3B2B20]">
                {language === 'th' ? 'ยังไม่มีอาหารในสำรับ' : 'Your bag is empty'}
              </p>
              <p className="text-xs font-thai-body text-[#786556]">
                {language === 'th'
                  ? 'เลือกเมนูอาหารไทยแสนอร่อยเพื่อเริ่มสำรับ'
                  : 'Explore delicious royal Thai dishes to start your order.'}
              </p>
            </div>
          ) : (
            cartItems.map((item) => {
              const addonsCost = item.selectedOptions.reduce((s, o) => s + o.price, 0);
              const itemUnitPrice = item.menuItem.price + addonsCost;
              const itemTotal = itemUnitPrice * item.quantity;

              return (
                <div
                  key={item.id}
                  className="p-3.5 bg-white rounded-xl border border-[#E8DFD3] shadow-xs flex flex-col gap-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                        {language === 'th' ? item.menuItem.nameTh : item.menuItem.nameEn}
                      </h4>
                      <div className="text-xs text-[#7A6759] mt-0.5 space-x-1">
                        <span>
                          {spiceLabels[item.selectedSpiceLevel as 0 | 1 | 2 | 3] || 'ปกติ'}
                        </span>
                        {item.selectedOptions.length > 0 && (
                          <span>
                            · {item.selectedOptions.map((o) => (language === 'th' ? o.nameTh : o.nameEn)).join(', ')}
                          </span>
                        )}
                      </div>
                      {item.specialInstructions && (
                        <p className="text-[11px] text-[#A16207] italic mt-0.5">
                          "{item.specialInstructions}"
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-[#A8988A] hover:text-[#8C2C1D] p-1 rounded transition-colors"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-[#F2ECE1]">
                    <div className="flex items-center border border-[#E0D5C7] rounded-lg p-0.5 bg-[#FAF8F5]">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="p-1 hover:bg-[#EAE0D3] rounded text-[#6E594B]"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-7 text-center text-xs font-bold tabular-nums text-[#2B1B17]">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="p-1 hover:bg-[#EAE0D3] rounded text-[#6E594B]"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-bold text-[#2B1B17] tabular-nums font-mono">
                        ฿{itemTotal.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer: Coupon, Summary & Checkout Button */}
        {cartItems.length > 0 && (
          <div className="p-4 bg-[#F4EFE6] border-t border-[#E8DFD3] space-y-3">
            {/* Promo code input */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#9C8B7E]" />
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  placeholder={language === 'th' ? 'ใส่โค้ดส่วนลด (เช่น RUEN10)' : 'Promo code (e.g. RUEN10)'}
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-[#D5C9B7] rounded-lg text-[#2B1B17] placeholder-[#A39284]"
                />
              </div>
              <button
                type="button"
                onClick={handleApplyCoupon}
                className="px-3 py-1.5 text-xs font-semibold bg-[#EAE0D3] hover:bg-[#DCD0C1] text-[#4A382C] rounded-lg"
              >
                {language === 'th' ? 'ใช้โค้ด' : 'Apply'}
              </button>
            </div>
            {couponError && <p className="text-[11px] text-red-600">{couponError}</p>}
            {appliedDiscount > 0 && (
              <p className="text-[11px] text-emerald-700 font-medium">
                {language === 'th'
                  ? `ใช้ส่วนลดสำเร็จ ประหยัด ฿${appliedDiscount.toLocaleString()}`
                  : `Discount applied: -฿${appliedDiscount.toLocaleString()}`}
              </p>
            )}

            {/* Calculations Breakdown */}
            <div className="space-y-1 text-xs text-[#6B5546] border-t border-[#EAE1D5] pt-2">
              <div className="flex justify-between">
                <span>{language === 'th' ? 'ค่าอาหารรวม' : 'Subtotal'}</span>
                <span className="tabular-nums font-mono">฿{subtotal.toLocaleString()}</span>
              </div>
              {appliedDiscount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>{language === 'th' ? 'ส่วนลดพิเศษ' : 'Discount'}</span>
                  <span className="tabular-nums font-mono">-฿{appliedDiscount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-xs text-[#8A776A]">
                <span>{language === 'th' ? 'ภาษีมูลค่าเพิ่ม 7% (รวมในราคาแล้ว)' : 'VAT 7% (Included)'}</span>
                <span className="tabular-nums font-mono">฿{Math.round(grandTotal * 0.07).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm font-bold text-[#2B1B17] pt-1 border-t border-[#E8DFD3]">
                <span>{language === 'th' ? 'ยอดชำระสุทธิ' : 'Total Amount'}</span>
                <span className="tabular-nums font-mono text-base text-[#8C2C1D]">
                  ฿{grandTotal.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Checkout Action */}
            <button
              onClick={handleSubmitOrder}
              className="w-full py-3 bg-[#8C2C1D] hover:bg-[#722115] text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-md active:scale-[0.99] transition-all"
            >
              <span>{language === 'th' ? 'ยืนยันการสั่งสำรับอาหาร' : 'Confirm & Place Order'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
