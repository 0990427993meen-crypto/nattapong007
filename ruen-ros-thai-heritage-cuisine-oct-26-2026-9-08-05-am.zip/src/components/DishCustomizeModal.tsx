import React, { useState } from 'react';
import { MenuItem, DishOption, CartItem } from '../data/menuData';
import { X, Flame, Clock, Check, Plus, Minus, Utensils } from 'lucide-react';

interface DishCustomizeModalProps {
  item: MenuItem | null;
  language: 'th' | 'en';
  onClose: () => void;
  onAddToCart: (cartItem: CartItem) => void;
}

export const DishCustomizeModal: React.FC<DishCustomizeModalProps> = ({
  item,
  language,
  onClose,
  onAddToCart,
}) => {
  if (!item) return null;

  const [quantity, setQuantity] = useState<number>(1);
  const [selectedSpiceLevel, setSelectedSpiceLevel] = useState<number>(item.spiceLevel);
  const [selectedOptions, setSelectedOptions] = useState<DishOption[]>([]);
  const [specialInstructions, setSpecialInstructions] = useState<string>('');

  const toggleOption = (opt: DishOption) => {
    if (selectedOptions.some((o) => o.id === opt.id)) {
      setSelectedOptions(selectedOptions.filter((o) => o.id !== opt.id));
    } else {
      setSelectedOptions([...selectedOptions, opt]);
    }
  };

  const optionsTotal = selectedOptions.reduce((sum, opt) => sum + opt.price, 0);
  const unitPrice = item.price + optionsTotal;
  const totalPrice = unitPrice * quantity;

  const handleConfirm = () => {
    const newCartItem: CartItem = {
      id: `${item.id}-${Date.now()}`,
      menuItem: item,
      quantity,
      selectedSpiceLevel,
      selectedOptions,
      specialInstructions: specialInstructions.trim() || undefined,
    };
    onAddToCart(newCartItem);
    onClose();
  };

  const spiceOptions = [
    { level: 0, labelTh: 'ไม่เผ็ด (0)', labelEn: 'Non-Spicy' },
    { level: 1, labelTh: 'เผ็ดน้อย (🌶)', labelEn: 'Mild' },
    { level: 2, labelTh: 'เผ็ดปานกลาง (🌶🌶)', labelEn: 'Medium' },
    { level: 3, labelTh: 'เผ็ดจัดจ้านถึงเครื่อง (🌶🌶🌶)', labelEn: 'Authentic Thai Hot' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div
        className="relative w-full max-w-lg bg-[#FAF8F5] rounded-2xl border border-[#E5DACD] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="px-6 py-4 border-b border-[#EAE0D3] flex items-center justify-between bg-[#F4EFE6]">
          <div className="flex items-center gap-2">
            <Utensils className="w-4 h-4 text-[#8C2C1D]" />
            <h3 className="text-base font-bold text-[#2B1B17] font-thai-title">
              {language === 'th' ? 'ปรับแต่งสำรับอาหาร' : 'Customize Your Dish'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#7A6759] hover:text-[#2B1B17] hover:bg-[#E5DACD] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-[#2B1B17]">
          {/* Dish Summary */}
          <div className="space-y-1">
            <h4 className="text-xl font-bold font-thai-title text-[#2B1B17]">
              {language === 'th' ? item.nameTh : item.nameEn}
            </h4>
            <p className="text-xs text-[#8C7667] font-display italic">
              {language === 'th' ? item.nameEn : item.nameTh}
            </p>
            <p className="text-xs sm:text-sm text-[#614E41] font-thai-body pt-1 leading-relaxed">
              {language === 'th' ? item.descriptionTh : item.descriptionEn}
            </p>
            <div className="flex items-center gap-4 text-xs text-[#7A6759] pt-2">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#8C2C1D]" />
                <span className="tabular-nums">{item.prepTimeMinutes} {language === 'th' ? 'นาที' : 'mins'}</span>
              </span>
              {item.calories && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">~{item.calories} kcal</span>
                </>
              )}
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-[#8C2C1D]">
                ฿{item.price.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Spice Level Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735E50] font-thai-title">
              {language === 'th' ? 'เลือกระดับความเผ็ด' : 'Select Spice Level'}
            </label>
            <div className="grid grid-cols-2 gap-2">
              {spiceOptions.map((opt) => {
                const isSelected = selectedSpiceLevel === opt.level;
                return (
                  <button
                    key={opt.level}
                    type="button"
                    onClick={() => setSelectedSpiceLevel(opt.level)}
                    className={`px-3 py-2.5 text-xs rounded-xl border text-left transition-all flex items-center justify-between ${
                      isSelected
                        ? 'border-[#8C2C1D] bg-[#F7EFE6] text-[#8C2C1D] font-bold shadow-xs'
                        : 'border-[#E0D5C7] bg-[#FDFBF7] text-[#59473A] hover:bg-[#F2ECE2]'
                    }`}
                  >
                    <span>{language === 'th' ? opt.labelTh : opt.labelEn}</span>
                    {isSelected && <Check className="w-4 h-4 text-[#8C2C1D]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Optional Add-ons */}
          {item.availableOptions && item.availableOptions.length > 0 && (
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#735E50] font-thai-title">
                {language === 'th' ? 'เครื่องเคียงและตัวเลือกเสริม' : 'Add-ons & Accompaniments'}
              </label>
              <div className="space-y-2">
                {item.availableOptions.map((opt) => {
                  const isChecked = selectedOptions.some((o) => o.id === opt.id);
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => toggleOption(opt)}
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-xs flex items-center justify-between transition-all ${
                        isChecked
                          ? 'border-[#8C2C1D] bg-[#F8EFE4] text-[#2B1B17]'
                          : 'border-[#E2D8CA] bg-[#FAF8F5] text-[#59473A] hover:bg-[#F0E9DF]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-4 h-4 rounded flex items-center justify-center border ${
                            isChecked
                              ? 'bg-[#8C2C1D] border-[#8C2C1D] text-white'
                              : 'border-[#C2B4A3] bg-white'
                          }`}
                        >
                          {isChecked && <Check className="w-3 h-3" />}
                        </div>
                        <span className="font-medium">
                          {language === 'th' ? opt.nameTh : opt.nameEn}
                        </span>
                      </div>
                      <span className="font-semibold text-[#8C2C1D] tabular-nums">
                        +฿{opt.price}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Special Instructions */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735E50] font-thai-title">
              {language === 'th' ? 'ข้อความถึงห้องเครื่อง (ถ้ามี)' : 'Special Dietary Request (Optional)'}
            </label>
            <input
              type="text"
              value={specialInstructions}
              onChange={(e) => setSpecialInstructions(e.target.value)}
              placeholder={
                language === 'th'
                  ? 'เช่น ไม่ใส่ผักชี, ไม่ใส่ชูรส, แยกน้ำแกง...'
                  : 'e.g. No cilantro, less oil, sauce on the side...'
              }
              className="w-full px-3.5 py-2 text-xs sm:text-sm bg-[#FAF8F5] border border-[#D9CFC1] rounded-lg text-[#2B1B17] placeholder-[#A39284] focus:outline-none focus:ring-1 focus:ring-[#8C2C1D]"
            />
          </div>
        </div>

        {/* Footer Actions: Quantity Stepper & Add Button */}
        <div className="px-6 py-4 border-t border-[#EAE0D3] bg-[#F4EFE6] flex items-center justify-between gap-4">
          {/* Quantity Stepper */}
          <div className="flex items-center border border-[#D4C7B5] bg-white rounded-lg p-1">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={quantity <= 1}
              className="p-1 rounded hover:bg-[#EAE0D3] text-[#5C483B] disabled:opacity-30"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="w-8 text-center text-sm font-bold tabular-nums text-[#2B1B17]">
              {quantity}
            </span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="p-1 rounded hover:bg-[#EAE0D3] text-[#5C483B]"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={handleConfirm}
            className="flex-1 py-3 px-4 bg-[#8C2C1D] hover:bg-[#722115] text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-between shadow-md active:scale-[0.99] transition-all"
          >
            <span>{language === 'th' ? 'เพิ่มลงสำรับ' : 'Add to Order'}</span>
            <span className="tabular-nums font-mono">฿{totalPrice.toLocaleString()}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
