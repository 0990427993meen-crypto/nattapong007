import React, { useState } from 'react';
import { MenuItem } from '../data/menuData';
import { Plus, Flame, Clock, Utensils } from 'lucide-react';

interface DishCardProps {
  item: MenuItem;
  language: 'th' | 'en';
  onSelectDish: (item: MenuItem) => void;
}

export const DishCard: React.FC<DishCardProps> = ({
  item,
  language,
  onSelectDish,
}) => {
  const [imageError, setImageError] = useState(false);

  // Render spice indicators cleanly without noisy pill clutter
  const renderSpiceIndicator = (level: number) => {
    if (level === 0) return null;
    const labels = {
      1: language === 'th' ? 'เผ็ดน้อย' : 'Mild Spicy',
      2: language === 'th' ? 'เผ็ดกลาง' : 'Medium Spicy',
      3: language === 'th' ? 'เผ็ดจัดจ้าน' : 'Authentic Spicy',
    };
    return (
      <span className="flex items-center gap-1 text-xs text-[#B45309] font-medium">
        <Flame className="w-3.5 h-3.5 text-[#B45309]" />
        <span>{labels[level as 1 | 2 | 3]}</span>
      </span>
    );
  };

  return (
    <div className="group flex flex-col bg-[#FAF8F5] rounded-xl border border-[#E8DFD3] hover:border-[#D0C2AE] hover:shadow-md transition-all duration-300 overflow-hidden">
      {/* Visual Image Slot */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#ECE4D8]">
        {item.image && !imageError ? (
          <img
            src={item.image}
            alt={language === 'th' ? item.nameTh : item.nameEn}
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#EAE2D5] to-[#DFD5C4] text-[#8C7565]">
            <Utensils className="w-10 h-10 mb-2 opacity-50 text-[#8C2C1D]" />
            <span className="text-sm font-semibold font-thai-title text-[#4A382C]">
              {language === 'th' ? item.nameTh : item.nameEn}
            </span>
            <span className="text-xs text-[#8A776A] mt-1 font-thai-body">
              {language === 'th' ? 'สำรับเรือนรสไทย' : 'Authentic Thai Special'}
            </span>
          </div>
        )}

        {/* Subtle Tag if Present (Quiet unboxed badge or subtle corner label) */}
        {item.tag && (
          <div className="absolute top-3 left-3 px-2.5 py-1 bg-[#2B1B17]/85 backdrop-blur-sm text-[#F7EFE3] text-[11px] font-medium rounded tracking-wide">
            {item.tag}
          </div>
        )}
      </div>

      {/* Card Content & Metadata */}
      <div className="p-5 flex flex-col flex-1 justify-between gap-4">
        <div className="space-y-2">
          {/* Metadata Row: Clean unboxed text with · separators */}
          <div className="flex items-center flex-wrap gap-2 text-xs text-[#7A6658]">
            {renderSpiceIndicator(item.spiceLevel)}
            {item.spiceLevel > 0 && <span aria-hidden="true">·</span>}
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#A8988A]" />
              <span className="tabular-nums">{item.prepTimeMinutes} {language === 'th' ? 'นาที' : 'mins'}</span>
            </span>
            {item.dietary && item.dietary[0] && (
              <>
                <span aria-hidden="true">·</span>
                <span>{item.dietary[0]}</span>
              </>
            )}
          </div>

          {/* Dish Names */}
          <div>
            <h3 className="text-lg font-bold text-[#2B1B17] font-thai-title group-hover:text-[#8C2C1D] transition-colors leading-snug">
              {language === 'th' ? item.nameTh : item.nameEn}
            </h3>
            <p className="text-xs text-[#8C7667] font-display italic mt-0.5">
              {language === 'th' ? item.nameEn : item.nameTh}
            </p>
          </div>

          {/* Culinary Description */}
          <p className="text-xs sm:text-sm text-[#665345] font-thai-body leading-relaxed line-clamp-2">
            {language === 'th' ? item.descriptionTh : item.descriptionEn}
          </p>
        </div>

        {/* Price & Action Row */}
        <div className="pt-3 border-t border-[#EAE1D5] flex items-center justify-between gap-3">
          <div className="flex items-baseline gap-1">
            <span className="text-xs font-medium text-[#8C7667]">฿</span>
            <span className="text-xl font-bold text-[#2B1B17] tabular-nums font-thai-title">
              {item.price.toLocaleString()}
            </span>
          </div>

          <button
            onClick={() => onSelectDish(item)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#8C2C1D] bg-[#F1E8DC] hover:bg-[#8C2C1D] hover:text-white rounded-lg transition-colors active:scale-95 whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'th' ? 'สั่งสำรับนี้' : 'Select'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
