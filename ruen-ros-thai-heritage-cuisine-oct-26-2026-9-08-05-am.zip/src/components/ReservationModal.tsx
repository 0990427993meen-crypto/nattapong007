import React, { useState } from 'react';
import { X, Calendar, Users, Clock, Sparkles, CheckCircle, MapPin } from 'lucide-react';
import { TableBooking } from '../data/menuData';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'th' | 'en';
}

export const ReservationModal: React.FC<ReservationModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [timeSlot, setTimeSlot] = useState('18:00');
  const [guestCount, setGuestCount] = useState(4);
  const [seatingArea, setSeatingArea] = useState<'indoor_thai_hall' | 'garden_patio' | 'lotus_pond_balcony'>('indoor_thai_hall');
  const [occasion, setOccasion] = useState('');
  const [confirmedBooking, setConfirmedBooking] = useState<TableBooking | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newBooking: TableBooking = {
      bookingId: `RRT-${Math.floor(1000 + Math.random() * 9000)}`,
      name,
      phone,
      date,
      timeSlot,
      guestCount,
      seatingArea,
      specialOccasion: occasion || undefined,
      createdAt: new Date().toLocaleDateString('th-TH'),
    };
    setConfirmedBooking(newBooking);
  };

  const seatingOptions = [
    {
      id: 'indoor_thai_hall',
      titleTh: 'ห้องเรือนไทยปรับอากาศ',
      titleEn: 'Air-Conditioned Heritage Hall',
      descTh: 'บรรยากาศเรือนไม้สักไทยโบราณ แอร์เย็นสบาย เหมาะสำหรับครอบครัว',
      descEn: 'Authentic teakwood craftsmanship, cool AC comfort.',
    },
    {
      id: 'garden_patio',
      titleTh: 'ระเบียงสวนไม้สักทอง',
      titleEn: 'Garden Teak Veranda',
      descTh: 'สัมผัสลมธรรมชาติและแมกไม้ไทยร่มรื่น เคล้าเสียงดนตรีไทยเดิม',
      descEn: 'Open-air lush tropical garden breeze and serene traditional sounds.',
    },
    {
      id: 'lotus_pond_balcony',
      titleTh: 'ศาลาริมสระบัวหลวง',
      titleEn: 'Lotus Pond Pavilion',
      descTh: 'โซนสุดโรแมนติกริมผืนน้ำบัวหลวงหลากสี เหมาะสำหรับโอกาสพิเศษ',
      descEn: 'Romantic waterside tables overlooking blooming Siamese water lilies.',
    },
  ] as const;

  const timeSlots = [
    '11:30', '12:00', '12:30', '13:00', '13:30',
    '17:30', '18:00', '18:30', '19:00', '19:30', '20:00'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div
        className="w-full max-w-lg bg-[#FAF8F5] rounded-2xl border border-[#E5DACD] shadow-2xl overflow-hidden flex flex-col text-[#2B1B17]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#F4EFE6] border-b border-[#E8DFD3] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#8C2C1D]" />
            <h3 className="text-base font-bold font-thai-title text-[#2B1B17]">
              {language === 'th' ? 'สำรองที่นั่งเรือนรสไทย' : 'Table Reservation'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#7A6759] hover:text-[#2B1B17] hover:bg-[#E5DACD]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {confirmedBooking ? (
          /* Confirmation Ticket */
          <div className="p-6 space-y-6 text-center">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h4 className="text-xl font-bold font-thai-title text-[#2B1B17]">
                {language === 'th' ? 'สำรองที่นั่งสำเร็จแล้ว' : 'Reservation Confirmed!'}
              </h4>
              <p className="text-xs text-[#705E51] font-thai-body">
                {language === 'th'
                  ? 'เรือนรสไทยขอขอบพระคุณ และยินดีต้อนรับท่านพร้อมคนพิเศษ'
                  : 'We look forward to welcoming you and your esteemed guests.'}
              </p>
            </div>

            <div className="bg-[#F2ECE1] p-5 rounded-xl border border-[#E0D5C7] text-left text-xs space-y-2.5">
              <div className="flex justify-between border-b border-[#E0D5C7] pb-2">
                <span className="text-[#7A6759]">{language === 'th' ? 'รหัสการจอง:' : 'Booking Ref:'}</span>
                <span className="font-mono font-bold text-sm text-[#8C2C1D]">
                  {confirmedBooking.bookingId}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A6759]">{language === 'th' ? 'ชื่อผู้จอง:' : 'Name:'}</span>
                <span className="font-semibold text-[#2B1B17]">{confirmedBooking.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A6759]">{language === 'th' ? 'วันที่และเวลา:' : 'Date & Time:'}</span>
                <span className="font-semibold text-[#2B1B17]">
                  {confirmedBooking.date} · {confirmedBooking.timeSlot} น.
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A6759]">{language === 'th' ? 'จำนวนที่นั่ง:' : 'Guests:'}</span>
                <span className="font-semibold text-[#2B1B17] tabular-nums">
                  {confirmedBooking.guestCount} {language === 'th' ? 'ท่าน' : 'guests'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#7A6759]">{language === 'th' ? 'โซนที่นั่ง:' : 'Seating Area:'}</span>
                <span className="font-semibold text-[#8C2C1D]">
                  {seatingOptions.find((s) => s.id === confirmedBooking.seatingArea)?.titleTh}
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3 bg-[#8C2C1D] hover:bg-[#722115] text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-colors"
            >
              {language === 'th' ? 'ปิดหน้านี้ / ไปยังเมนูอาหาร' : 'Close & View Menu'}
            </button>
          </div>
        ) : (
          /* Booking Form */
          <form onSubmit={handleSubmit} className="p-6 overflow-y-auto max-h-[75vh] space-y-5">
            {/* Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#594639] font-thai-title">
                  {language === 'th' ? 'ชื่อผู้ติดต่อ *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={language === 'th' ? 'เช่น คุณสมศักดิ์ วรเดช' : 'John Doe'}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-[#D5C9B7] rounded-lg text-[#2B1B17] focus:outline-none focus:ring-1 focus:ring-[#8C2C1D]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#594639] font-thai-title">
                  {language === 'th' ? 'เบอร์โทรศัพท์ *' : 'Phone Number *'}
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="08X-XXX-XXXX"
                  className="w-full px-3.5 py-2 text-xs bg-white border border-[#D5C9B7] rounded-lg text-[#2B1B17] focus:outline-none focus:ring-1 focus:ring-[#8C2C1D]"
                />
              </div>
            </div>

            {/* Date, Time, Guest Count */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#594639] font-thai-title">
                  {language === 'th' ? 'วันที่ *' : 'Date *'}
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-[#D5C9B7] rounded-lg text-[#2B1B17]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#594639] font-thai-title">
                  {language === 'th' ? 'เวลา *' : 'Time *'}
                </label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-[#D5C9B7] rounded-lg text-[#2B1B17]"
                >
                  {timeSlots.map((slot) => (
                    <option key={slot} value={slot}>
                      {slot} น.
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#594639] font-thai-title">
                  {language === 'th' ? 'จำนวนแขก *' : 'Guests *'}
                </label>
                <select
                  value={guestCount}
                  onChange={(e) => setGuestCount(Number(e.target.value))}
                  className="w-full px-3 py-1.5 text-xs bg-white border border-[#D5C9B7] rounded-lg text-[#2B1B17]"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16].map((n) => (
                    <option key={n} value={n}>
                      {n} {language === 'th' ? 'ท่าน' : 'guests'}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Seating Zone Cards */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-[#594639] font-thai-title">
                {language === 'th' ? 'เลือกโซนบรรยากาศเรือนไทย' : 'Select Seating Atmosphere'}
              </label>
              <div className="space-y-2">
                {seatingOptions.map((area) => {
                  const isSelected = seatingArea === area.id;
                  return (
                    <div
                      key={area.id}
                      onClick={() => setSeatingArea(area.id)}
                      className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        isSelected
                          ? 'border-[#8C2C1D] bg-[#F7EFE6] ring-1 ring-[#8C2C1D]'
                          : 'border-[#E0D5C7] bg-white hover:bg-[#FAF6F0]'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold text-[#2B1B17]">
                        <span>{language === 'th' ? area.titleTh : area.titleEn}</span>
                        {isSelected && <span className="text-[#8C2C1D] text-xs">✓ เลือกโซนนี้</span>}
                      </div>
                      <p className="text-[11px] text-[#705E51] font-thai-body mt-0.5">
                        {language === 'th' ? area.descTh : area.descEn}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Special Occasion */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-[#594639] font-thai-title">
                {language === 'th' ? 'โอกาสพิเศษ / คำขอเพิ่มเติม (ถ้ามี)' : 'Special Occasion / Requests'}
              </label>
              <input
                type="text"
                value={occasion}
                onChange={(e) => setOccasion(e.target.value)}
                placeholder={
                  language === 'th'
                    ? 'เช่น วันเกิด, วันครบรอบแต่งงาน, ต้องการเก้าอี้เด็ก...'
                    : 'e.g. Birthday, Anniversary, High chair needed...'
                }
                className="w-full px-3.5 py-2 text-xs bg-white border border-[#D5C9B7] rounded-lg text-[#2B1B17]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-[#8C2C1D] hover:bg-[#722115] text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-all active:scale-[0.99]"
            >
              {language === 'th' ? 'ยืนยันการสำรองโต๊ะ' : 'Confirm Table Booking'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
