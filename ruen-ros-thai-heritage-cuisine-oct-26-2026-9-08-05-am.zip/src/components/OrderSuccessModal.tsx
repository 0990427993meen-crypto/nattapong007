import React from 'react';
import { CheckCircle2, Clock, MapPin, Utensils, Printer, X } from 'lucide-react';
import { CartItem } from '../data/menuData';

interface OrderSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderNumber: string;
  items: CartItem[];
  grandTotal: number;
  serviceType: 'dine_in' | 'takeaway';
  tableNumber?: string;
  customerName?: string;
  language: 'th' | 'en';
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  isOpen,
  onClose,
  orderNumber,
  items,
  grandTotal,
  serviceType,
  tableNumber,
  customerName,
  language,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div
        className="w-full max-w-md bg-[#FAF8F5] rounded-2xl border border-[#E5DACD] shadow-2xl overflow-hidden flex flex-col text-[#2B1B17]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner with Thai Motif Tone */}
        <div className="bg-[#8C2C1D] text-white p-6 text-center space-y-2">
          <div className="w-12 h-12 mx-auto bg-white/10 rounded-full flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8 text-[#FCD34D]" />
          </div>
          <h3 className="text-xl font-bold font-thai-title">
            {language === 'th' ? 'สั่งสำรับอาหารสำเร็จ' : 'Order Received!'}
          </h3>
          <p className="text-xs text-[#F5E6CC] font-thai-body">
            {language === 'th'
              ? 'ห้องเครื่องเรือนรสไทยกำลังบรรจงปรุงอาหารด้วยความประณีต'
              : 'Our royal kitchen is preparing your dishes with care.'}
          </p>
          <div className="pt-2 text-xs font-mono tracking-widest text-[#FCD34D]">
            ORDER #{orderNumber}
          </div>
        </div>

        {/* Live Kitchen Preparation Progress */}
        <div className="p-5 bg-[#F2ECE1] border-b border-[#E3D8C8]">
          <div className="text-xs font-bold uppercase tracking-wider text-[#735E50] mb-3 font-thai-title">
            {language === 'th' ? 'สถานะห้องเครื่อง' : 'Kitchen Status'}
          </div>
          <div className="flex items-center justify-between text-xs text-[#5C4A3E]">
            <div className="flex flex-col items-center gap-1">
              <span className="w-6 h-6 rounded-full bg-[#8C2C1D] text-white flex items-center justify-center font-bold text-[10px]">
                1
              </span>
              <span className="font-semibold">{language === 'th' ? 'รับออเดอร์' : 'Received'}</span>
            </div>
            <div className="flex-1 h-[2px] bg-[#8C2C1D] mx-2" />
            <div className="flex flex-col items-center gap-1">
              <span className="w-6 h-6 rounded-full bg-[#8C2C1D] text-white flex items-center justify-center font-bold text-[10px] ring-2 ring-[#FCD34D]">
                2
              </span>
              <span className="font-bold text-[#8C2C1D]">{language === 'th' ? 'กำลังปรุง' : 'Cooking'}</span>
            </div>
            <div className="flex-1 h-[2px] bg-[#D4C7B5] mx-2" />
            <div className="flex flex-col items-center gap-1">
              <span className="w-6 h-6 rounded-full bg-[#E0D4C3] text-[#735E50] flex items-center justify-center font-bold text-[10px]">
                3
              </span>
              <span className="text-[#8C7667]">{language === 'th' ? 'พร้อมเสิร์ฟ' : 'Serving'}</span>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-[#6B5546] bg-white/70 py-2 px-3 rounded-lg border border-[#E0D5C7]">
            <Clock className="w-4 h-4 text-[#8C2C1D]" />
            <span>
              {language === 'th'
                ? 'ระยะเวลาปรุงโดยประมาณ 15 - 20 นาที'
                : 'Estimated prep time: 15 - 20 minutes'}
            </span>
          </div>
        </div>

        {/* Order Receipt Details */}
        <div className="p-5 overflow-y-auto max-h-60 space-y-3">
          <div className="flex items-center justify-between text-xs text-[#7A6759] border-b border-[#EAE1D5] pb-2">
            <span>
              {serviceType === 'dine_in'
                ? `${language === 'th' ? 'เสิร์ฟที่:' : 'Serving at:'} ${tableNumber}`
                : `${language === 'th' ? 'สั่งกลับโดย:' : 'Takeaway for:'} ${customerName}`}
            </span>
            <span>{items.length} {language === 'th' ? 'รายการ' : 'items'}</span>
          </div>

          <div className="space-y-2">
            {items.map((item) => (
              <div key={item.id} className="flex justify-between text-xs">
                <div>
                  <span className="font-semibold text-[#2B1B17]">
                    {item.quantity}x {language === 'th' ? item.menuItem.nameTh : item.menuItem.nameEn}
                  </span>
                  {item.selectedOptions.length > 0 && (
                    <div className="text-[11px] text-[#786556]">
                      + {item.selectedOptions.map((o) => (language === 'th' ? o.nameTh : o.nameEn)).join(', ')}
                    </div>
                  )}
                </div>
                <span className="font-mono tabular-nums text-[#4A382C]">
                  ฿{((item.menuItem.price + item.selectedOptions.reduce((s, o) => s + o.price, 0)) * item.quantity).toLocaleString()}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-[#EAE1D5] flex justify-between text-sm font-bold text-[#2B1B17]">
            <span>{language === 'th' ? 'ยอดสุทธิ' : 'Total Paid'}</span>
            <span className="font-mono tabular-nums text-[#8C2C1D]">
              ฿{grandTotal.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-4 bg-[#F4EFE6] border-t border-[#E8DFD3] flex items-center gap-3">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2.5 text-xs font-semibold text-[#5C483B] bg-white border border-[#D5C9B7] rounded-xl hover:bg-[#EAE0D3] flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>{language === 'th' ? 'พิมพ์ใบเสร็จ' : 'Print'}</span>
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-[#8C2C1D] hover:bg-[#722115] text-white text-xs sm:text-sm font-bold rounded-xl transition-colors shadow-xs"
          >
            {language === 'th' ? 'เรียบร้อย / สั่งอาหารเพิ่ม' : 'Done / Order More'}
          </button>
        </div>
      </div>
    </div>
  );
};
