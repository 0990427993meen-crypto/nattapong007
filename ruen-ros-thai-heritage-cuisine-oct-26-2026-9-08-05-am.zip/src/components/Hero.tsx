import React from 'react';
import { ArrowDown, Flame, Award, HeartHandshake, Leaf, Clock } from 'lucide-react';

interface HeroProps {
  language: 'th' | 'en';
  onScrollToMenu: () => void;
  onOpenReservation: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  language,
  onScrollToMenu,
  onOpenReservation,
}) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-14 bg-gradient-to-b from-[#F5EFE6] to-[#FAF7F2] border-b border-[#E7DFD3]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Split Screen 2-Column Hero */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Authentic Brand Narrative */}
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs font-medium text-[#8C2C1D] uppercase tracking-widest font-thai-title">
              <span>{language === 'th' ? 'รสแท้ต้นตำรับสยาม' : 'Siamese Royal Culinary Heritage'}</span>
              <span aria-hidden="true">·</span>
              <span>{language === 'th' ? 'โขลกสด ปรุงเตาถ่าน' : 'Charcoal Cooked'}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2B1B17] font-thai-title leading-[1.25] tracking-tight [text-wrap:balance]">
              {language === 'th' ? (
                <>
                  เสน่ห์สำรับไทยโบราณ <br />
                  <span className="text-[#8C2C1D] font-display italic font-normal">
                    รสมือชาววังแท้
                  </span>{' '}
                  อันวิจิตรประณีต
                </>
              ) : (
                <>
                  The Authentic Soul of <br />
                  <span className="text-[#8C2C1D] font-display italic font-normal">
                    Royal Thai Gastronomy
                  </span>
                </>
              )}
            </h1>

            <p className="text-base sm:text-lg text-[#5E4D41] leading-relaxed font-thai-body max-w-xl">
              {language === 'th'
                ? 'ยินดีต้อนรับสู่เรือนรสไทย สัมผัสความละเมียดละไมของอาหารไทยดั้งเดิม พริกแกงโขลกมือสดใหม่ทุกเช้า กะทิคั้นสดแท้ และวัตถุดิบอินทรีย์จากแหล่งกำเนิดท้องถิ่นทั่วสยามประเทศ'
                : 'Welcome to Ruen Ros Thai. Experience time-honored Siamese recipes passed down through three generations—featuring stone-mortar pounded herbs, cold-pressed coconut milk, and fresh wild river delicacies.'}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onScrollToMenu}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-[#8C2C1D] hover:bg-[#722115] active:scale-[0.98] rounded-xl shadow-md hover:shadow-lg transition-all flex items-center gap-2"
              >
                <span>{language === 'th' ? 'เลือกชมเมนูอาหาร' : 'Explore Menu'}</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenReservation}
                className="px-6 py-3.5 text-sm font-semibold text-[#3B2519] bg-[#EDE5D8] hover:bg-[#E2D8C7] border border-[#D5C9B7] rounded-xl transition-all"
              >
                {language === 'th' ? 'สำรองที่นั่งล่วงหน้า' : 'Book a Table'}
              </button>
            </div>

            {/* Quiet Social Proof Adjacency */}
            <div className="pt-4 border-t border-[#E3D9CA] flex items-center gap-8 text-xs text-[#705B4E]">
              <div>
                <span className="font-bold text-base text-[#2B1B17] tabular-nums">4.9 / 5.0</span>
                <span className="block">{language === 'th' ? 'คะแนนรีวิวผู้มาเยือน' : 'Diner Ratings (800+)'}</span>
              </div>
              <div className="h-8 w-[1px] bg-[#D8CEBF]" />
              <div>
                <span className="font-bold text-base text-[#2B1B17] tabular-nums">3 รุ่น</span>
                <span className="block">{language === 'th' ? 'สูตรลับตกทอด 65 ปี' : 'Years of Royal Recipes'}</span>
              </div>
              <div className="h-8 w-[1px] bg-[#D8CEBF]" />
              <div>
                <span className="font-bold text-base text-[#8C2C1D]">100%</span>
                <span className="block">{language === 'th' ? 'สมุนไพรอินทรีย์สด' : 'Organic Thai Herbs'}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Feast Showcase */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#D9CEBE] shadow-2xl aspect-[16/10] bg-[#E8E0D2]">
              <img
                src="/src/assets/images/hero_thai_feast_1792980142825.jpg"
                alt="สำรับอาหารไทยโบราณ เรือนรสไทย Traditional Thai Royal Feast"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transform hover:scale-[1.02] transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/10 pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 text-white">
                <p className="text-xs font-medium uppercase tracking-wider text-[#FCD34D]">
                  {language === 'th' ? 'สำรับมงคลประจำฤดูกาล' : 'Heritage Royal Samrub'}
                </p>
                <p className="text-sm sm:text-base font-semibold text-[#FDFBF7] font-thai-title">
                  {language === 'th'
                    ? 'ต้มยำกุ้งแม่น้ำ · มัสมั่นน่องลาย · ผัดไทยกุ้งสด · ข้าวเหนียวมะม่วง'
                    : 'River Prawn Tom Yum · Beef Massaman · Pad Thai · Sweet Mango Sticky Rice'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Full-width 4-Column Feature Strip */}
        <div className="mt-12 pt-8 border-t border-[#E3D9CA] grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-[#EFE8DC] text-[#8C2C1D] shrink-0 mt-0.5">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                {language === 'th' ? 'เตาถ่านโบราณ' : 'Charcoal Simmered'}
              </h2>
              <p className="text-xs text-[#6B5546] font-thai-body mt-0.5">
                {language === 'th' ? 'หอมกลิ่นกระทะและควันไม้มะขาม' : 'Traditional smoky wok hei'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-[#EFE8DC] text-[#8C2C1D] shrink-0 mt-0.5">
              <Leaf className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                {language === 'th' ? 'สมุนไพรพื้นถิ่นสด' : 'Wild Organic Herbs'}
              </h2>
              <p className="text-xs text-[#6B5546] font-thai-body mt-0.5">
                {language === 'th' ? 'คัดสรรจากสวนปลอดสารพิษ' : 'Farm-to-table botanical herbs'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-[#EFE8DC] text-[#8C2C1D] shrink-0 mt-0.5">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                {language === 'th' ? 'สูตรชาววังตกทอด' : 'Royal Heritage Recipes'}
              </h2>
              <p className="text-xs text-[#6B5546] font-thai-body mt-0.5">
                {language === 'th' ? 'รสมือแท้ ครบ เปรี้ยว เค็ม เผ็ด หวาน' : 'Balanced harmonized flavors'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-[#EFE8DC] text-[#8C2C1D] shrink-0 mt-0.5">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                {language === 'th' ? 'ปรุงสดจานต่อจาน' : 'Freshly Crafted'}
              </h2>
              <p className="text-xs text-[#6B5546] font-thai-body mt-0.5">
                {language === 'th' ? 'เสิร์ฟร้อนพร้อมกลิ่นหอมกรุ่น' : 'Cooked upon each single order'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
