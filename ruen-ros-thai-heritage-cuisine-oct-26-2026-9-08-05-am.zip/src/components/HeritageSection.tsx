import React from 'react';
import { Sparkles, Utensils, Star, Quote } from 'lucide-react';

interface HeritageSectionProps {
  language: 'th' | 'en';
}

export const HeritageSection: React.FC<HeritageSectionProps> = ({ language }) => {
  const testimonials = [
    {
      name: 'คุณพัชราภรณ์ วัฒนพาณิชย์',
      role: 'นักชิมอาหารไทยโบราณ',
      rating: 5,
      commentTh:
        'ต้มยำกุ้งแม่น้ำโบราณรสชาติต้นตำรับที่หาทานยากมากในยุคนี้ น้ำซุปเข้มข้นถึงเครื่อง พริกแกงหอมละมุนไม่บาดคอ ข้าวเหนียวมะม่วงกะทิหอมควันเทียนชื่นใจที่สุด',
      commentEn:
        'The Tom Yum Goong is an authentic masterpiece rarely found nowadays. The coconut smoke aroma in their Mango Sticky Rice is unforgettable.',
    },
    {
      name: 'Dr. Marcus Vance',
      role: 'Culinary Travel Writer, Bangkok Post',
      rating: 5,
      commentTh:
        'แกงมัสมั่นเนื้อน่องลายตุ๋นเตาถ่าน 6 ชั่วโมงคือที่สุดของความประณีต นุ่มละลาย เครื่องแกงมัสมั่นลึกซึ้งและกลมกล่อมระดับโลก',
      commentEn:
        'The 6-hour charcoal braised beef shank Massaman is the pinnacle of Siamese culinary balance. Nuanced, rich, and unforgettable.',
    },
    {
      name: 'คุณธีรเดช สุวรรณประสิทธิ์',
      role: 'ลูกค้าประจำ พาครอบครัวมาทานทุกเดือน',
      rating: 5,
      commentTh:
        'บรรยากาศเรือนไม้สักริมสระบัวร่มรื่นมาก คุณพ่อคุณแม่ชมปลากะพงทอดน้ำปลาและผัดไทยห่อไข่ว่าอร่อยเหมือนรสมือคุณยายที่เคยทำให้ทานตอนเด็ก',
      commentEn:
        'The tranquil teakwood veranda overlooking the lotus pond makes every family gathering special. Authentic nostalgic flavors.',
    },
  ];

  return (
    <section id="heritage" className="py-20 bg-[#F4EFE6] border-t border-b border-[#E5DACD]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Editorial Story Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-5">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#8C2C1D]">
              <Sparkles className="w-4 h-4 text-[#8C2C1D]" />
              <span>{language === 'th' ? 'เรื่องเล่าแห่งเรือนรสไทย' : 'The Ruen Ros Heritage'}</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-bold text-[#2B1B17] font-thai-title leading-tight [text-wrap:balance]">
              {language === 'th' ? (
                <>
                  รังสรรค์ด้วยความเคารพใน <br />
                  <span className="font-display italic text-[#8C2C1D] font-normal">
                    ศาสตร์และศิลป์แห่งสำรับไทย
                  </span>
                </>
              ) : (
                <>
                  Rooted in Respect for <br />
                  <span className="font-display italic text-[#8C2C1D] font-normal">
                    Ancient Siamese Culinary Art
                  </span>
                </>
              )}
            </h2>

            <p className="text-sm sm:text-base text-[#5E4D41] font-thai-body leading-relaxed">
              {language === 'th'
                ? 'เรือนรสไทยก่อตั้งขึ้นจากความตั้งใจที่จะอนุรักษ์รสชาติอาหารไทยโบราณแท้ๆ มิให้เลือนหายไปตามกาลเวลา ทุกเช้าตรู่ ห้องเครื่องของเราจะบรรจงโขลกพริกแกงสดด้วยครกหินอ่างศิลา ใช้กะทิคั้นสดแท้รอบแรก และน้ำตาลโตนดแท้จากสวนตาลโตนดเมืองเพชรบุรี'
                : 'Founded to preserve authentic heritage recipes, our kitchen begins each dawn with stone-mortar ground curry pastes, fresh single-press coconut milk, and unrefined Phetchaburi palm sugar.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3">
              <div className="p-4 bg-white/70 rounded-xl border border-[#E0D5C7]">
                <h4 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                  {language === 'th' ? 'ครกหินตำสด' : 'Stone Pounded'}
                </h4>
                <p className="text-xs text-[#735F52] font-thai-body mt-1">
                  {language === 'th' ? 'ดึงน้ำมันหอมระเหยจากสมุนไพร' : 'Preserving essential herbal oils'}
                </p>
              </div>

              <div className="p-4 bg-white/70 rounded-xl border border-[#E0D5C7]">
                <h4 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                  {language === 'th' ? 'ตาลโตนดแท้' : 'Wild Palm Sugar'}
                </h4>
                <p className="text-xs text-[#735F52] font-thai-body mt-1">
                  {language === 'th' ? 'หวานนุ่มละมุนไม่แหลมแสบคอ' : 'Subtle rounded caramel sweetness'}
                </p>
              </div>

              <div className="p-4 bg-white/70 rounded-xl border border-[#E0D5C7]">
                <h4 className="text-sm font-bold text-[#2B1B17] font-thai-title">
                  {language === 'th' ? 'ไฟเตาถ่าน' : 'Charcoal Glow'}
                </h4>
                <p className="text-xs text-[#735F52] font-thai-body mt-1">
                  {language === 'th' ? 'ความร้อนคงที่ ตุ๋นเข้มเข้าเนื้อ' : 'Even gentle heat penetration'}
                </p>
              </div>
            </div>
          </div>

          {/* Right Visual Story Collage */}
          <div className="lg:col-span-6 relative">
            <div className="rounded-2xl overflow-hidden border border-[#D5C9B7] shadow-xl aspect-[4/3] bg-[#E8E0D2] relative">
              <img
                src="/src/assets/images/dish_massaman_beef_1792980144159.jpg"
                alt="แกงมัสมั่นเนื้อน่องลายสูตรชาววังเตาถ่าน"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 text-white">
                <span className="text-xs font-mono tracking-widest uppercase text-[#FCD34D]">
                  {language === 'th' ? 'ตำรับยอดนิยมอันดับหนึ่ง' : 'World Acclaimed Recipe'}
                </span>
                <p className="text-lg font-bold font-thai-title text-[#FAF7F2]">
                  {language === 'th'
                    ? 'แกงมัสมั่นเนื้อน่องลายตุ๋นเตาถ่าน 6 ชั่วโมง'
                    : '6-Hour Charcoal Braised Massaman Beef Shank'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Customer Testimonials Grid (Claim-to-Proof Adjacency) */}
        <div className="space-y-6 pt-6 border-t border-[#E3D8C8]">
          <div className="text-center space-y-1">
            <h3 className="text-xl sm:text-2xl font-bold text-[#2B1B17] font-thai-title">
              {language === 'th' ? 'ความประทับใจจากผู้มาเยือนเรือนรสไทย' : 'Guest Reviews & Praise'}
            </h3>
            <p className="text-xs text-[#735F52]">
              {language === 'th'
                ? 'คำนิยมจริงจากผู้ชื่นชอบรสชาติอาหารไทยโบราณ'
                : 'Genuine dining impressions from heritage Thai food enthusiasts.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, index) => (
              <div
                key={index}
                className="p-6 bg-[#FAF8F5] rounded-xl border border-[#E2D6C6] shadow-xs flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-1 text-[#D97706]">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-xs sm:text-sm text-[#4A382C] font-thai-body leading-relaxed italic">
                    "{language === 'th' ? t.commentTh : t.commentEn}"
                  </p>
                </div>

                <div className="pt-3 border-t border-[#EAE0D3]">
                  <p className="text-xs font-bold text-[#2B1B17] font-thai-title">{t.name}</p>
                  <p className="text-[11px] text-[#7A6759] font-thai-body">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
