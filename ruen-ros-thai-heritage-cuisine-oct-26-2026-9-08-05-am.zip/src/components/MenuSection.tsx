import React, { useState, useMemo } from 'react';
import { CATEGORIES, MENU_ITEMS, MenuItem } from '../data/menuData';
import { DishCard } from './DishCard';
import { Search, SlidersHorizontal, RotateCcw } from 'lucide-react';

interface MenuSectionProps {
  language: 'th' | 'en';
  onSelectDish: (item: MenuItem) => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({
  language,
  onSelectDish,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSpiceFilter, setSelectedSpiceFilter] = useState<number | 'all'>('all');
  const [selectedDietary, setSelectedDietary] = useState<string>('all');

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      // Category check
      if (activeCategory !== 'all' && item.category !== activeCategory) {
        return false;
      }
      // Spice check
      if (selectedSpiceFilter !== 'all' && item.spiceLevel !== selectedSpiceFilter) {
        return false;
      }
      // Dietary check
      if (selectedDietary !== 'all') {
        const hasDietary = item.dietary?.some((d) => d.includes(selectedDietary));
        if (!hasDietary) return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesTh = item.nameTh.toLowerCase().includes(query);
        const matchesEn = item.nameEn.toLowerCase().includes(query);
        const matchesDescTh = item.descriptionTh.toLowerCase().includes(query);
        const matchesDescEn = item.descriptionEn.toLowerCase().includes(query);
        return matchesTh || matchesEn || matchesDescTh || matchesDescEn;
      }
      return true;
    });
  }, [activeCategory, selectedSpiceFilter, selectedDietary, searchQuery]);

  const resetFilters = () => {
    setActiveCategory('all');
    setSearchQuery('');
    setSelectedSpiceFilter('all');
    setSelectedDietary('all');
  };

  const isFiltered =
    activeCategory !== 'all' ||
    searchQuery !== '' ||
    selectedSpiceFilter !== 'all' ||
    selectedDietary !== 'all';

  return (
    <section id="menu" className="py-16 bg-[#FAF7F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <p className="text-xs uppercase tracking-widest font-semibold text-[#8C2C1D]">
            {language === 'th' ? 'สำรับคาวหวานรสประณีต' : 'Heritage Culinary Collection'}
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#2B1B17] font-thai-title tracking-tight">
            {language === 'th' ? 'เมนูอาหารไทยชาววัง' : 'Authentic Thai Gastronomy'}
          </h2>
          <p className="text-sm sm:text-base text-[#6B5546] font-thai-body">
            {language === 'th'
              ? 'รังสรรค์ด้วยความพิถีพิถันจากวัตถุดิบอินทรีย์สดใหม่ ครบรสสัมผัสไทยโบราณ'
              : 'Handcrafted with stone-ground pastes, slow charcoal fire, and organic royal court recipes.'}
          </p>
        </div>

        {/* Interactive Controls Bar */}
        <div className="space-y-4">
          {/* Category Tabs: Segmented style buttons */}
          <div className="flex items-center overflow-x-auto pb-2 scrollbar-none gap-2 justify-start lg:justify-center">
            {CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2.5 text-xs sm:text-sm font-medium rounded-lg whitespace-nowrap shrink-0 transition-colors ${
                    isActive
                      ? 'bg-[#8C2C1D] text-white shadow-sm font-semibold'
                      : 'bg-[#F0E9DF] text-[#5C483B] hover:bg-[#E6DEC2] hover:text-[#2B1B17]'
                  }`}
                >
                  {language === 'th' ? cat.nameTh : cat.nameEn}
                </button>
              );
            })}
          </div>

          {/* Search & Refinement Filters */}
          <div className="bg-[#F2ECE2] p-4 rounded-xl border border-[#E3D9CC] flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8C7565]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  language === 'th'
                    ? 'ค้นหาชื่อเมนู, วัตถุดิบ (เช่น กุ้งแม่น้ำ, มัสมั่น, ข้าวเหนียว)...'
                    : 'Search by dish or ingredients (e.g. Tom Yum, Prawn, Mango)...'
                }
                className="w-full pl-10 pr-4 py-2 bg-[#FAF8F5] border border-[#D9CFC1] rounded-lg text-xs sm:text-sm text-[#2B1B17] placeholder-[#9C8B7E] focus:outline-none focus:ring-1 focus:ring-[#8C2C1D]"
              />
            </div>

            {/* Quick Filter Selectors */}
            <div className="flex flex-wrap items-center gap-3 text-xs">
              {/* Spice Filter */}
              <div className="flex items-center gap-1.5">
                <span className="text-[#6E594B] font-medium">
                  {language === 'th' ? 'ระดับความเผ็ด:' : 'Spice:'}
                </span>
                <select
                  value={selectedSpiceFilter}
                  onChange={(e) =>
                    setSelectedSpiceFilter(
                      e.target.value === 'all' ? 'all' : Number(e.target.value)
                    )
                  }
                  className="bg-[#FAF8F5] border border-[#D9CFC1] rounded-lg px-2.5 py-1.5 text-xs text-[#2B1B17] focus:outline-none focus:ring-1 focus:ring-[#8C2C1D]"
                >
                  <option value="all">{language === 'th' ? 'ทุกระดับ' : 'All Levels'}</option>
                  <option value={0}>{language === 'th' ? 'ไม่เผ็ด (0)' : 'Non-Spicy (0)'}</option>
                  <option value={1}>{language === 'th' ? 'เผ็ดน้อย (🌶)' : 'Mild (1)'}</option>
                  <option value={2}>{language === 'th' ? 'เผ็ดกลาง (🌶🌶)' : 'Medium (2)'}</option>
                  <option value={3}>{language === 'th' ? 'เผ็ดจัดจ้าน (🌶🌶🌶)' : 'Authentic Spicy (3)'}</option>
                </select>
              </div>

              {/* Dietary Filter */}
              <div className="flex items-center gap-1.5">
                <span className="text-[#6E594B] font-medium">
                  {language === 'th' ? 'ประเภท:' : 'Type:'}
                </span>
                <select
                  value={selectedDietary}
                  onChange={(e) => setSelectedDietary(e.target.value)}
                  className="bg-[#FAF8F5] border border-[#D9CFC1] rounded-lg px-2.5 py-1.5 text-xs text-[#2B1B17] focus:outline-none focus:ring-1 focus:ring-[#8C2C1D]"
                >
                  <option value="all">{language === 'th' ? 'ทั้งหมด' : 'All Types'}</option>
                  <option value="อาหารทะเล">{language === 'th' ? 'ซีฟู้ด / กุ้งปลา' : 'Seafood'}</option>
                  <option value="เนื้อวัว">{language === 'th' ? 'เนื้อวัว' : 'Beef'}</option>
                  <option value="เนื้อไก่">{language === 'th' ? 'เนื้อไก่' : 'Chicken'}</option>
                  <option value="มังสวิรัติ">{language === 'th' ? 'มังสวิรัติ / ขนมหวาน' : 'Vegetarian / Sweets'}</option>
                </select>
              </div>

              {/* Reset Button */}
              {isFiltered && (
                <button
                  onClick={resetFilters}
                  className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-[#8C2C1D] hover:bg-[#E5DACD] rounded-lg transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{language === 'th' ? 'ล้างตัวกรอง' : 'Reset'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Results Summary Metadata */}
          <div className="flex items-center justify-between text-xs text-[#7A6759] px-1">
            <span>
              {language === 'th'
                ? `พบอาหาร ${filteredItems.length} รายการ`
                : `Showing ${filteredItems.length} dishes`}
            </span>
            <span className="hidden sm:inline">
              {language === 'th'
                ? 'เลือกกดที่เมนูเพื่อปรับระดับความเผ็ดและเพิ่มเครื่องเคียง'
                : 'Click any dish to customize spice and ingredients'}
            </span>
          </div>
        </div>

        {/* 3-Column Product Grid */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredItems.map((item) => (
              <DishCard
                key={item.id}
                item={item}
                language={language}
                onSelectDish={onSelectDish}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-[#F6F0E6] rounded-xl border border-[#E5DBCC] space-y-3">
            <p className="text-base font-bold text-[#3D2C21] font-thai-title">
              {language === 'th' ? 'ไม่พบเมนูอาหารที่ค้นหา' : 'No dishes found'}
            </p>
            <p className="text-xs text-[#7A6759] font-thai-body">
              {language === 'th'
                ? 'ลองปรับคำค้นหา หรือกดล้างตัวกรองเพื่อดูเมนูทั้งหมด'
                : 'Try searching with another keyword or reset active filters.'}
            </p>
            <button
              onClick={resetFilters}
              className="mt-2 px-4 py-2 text-xs font-semibold text-white bg-[#8C2C1D] rounded-lg hover:bg-[#722115]"
            >
              {language === 'th' ? 'ดูเมนูอาหารทั้งหมด' : 'Show All Dishes'}
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
