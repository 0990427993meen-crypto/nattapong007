import React from 'react';
import { ShoppingBag, Calendar, Phone, UtensilsCrossed, Globe } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenReservation: () => void;
  language: 'th' | 'en';
  onToggleLanguage: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenCart,
  onOpenReservation,
  language,
  onToggleLanguage,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-[#E7E0D3] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element wordmark, no pill badges) */}
        <a href="#" className="flex items-center gap-3 shrink-0 group">
          <div className="w-10 h-10 rounded-lg bg-[#8C2C1D] flex items-center justify-center text-[#F5E6CC] shadow-sm">
            <UtensilsCrossed className="w-5 h-5" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl sm:text-2xl font-bold tracking-tight text-[#2B1B17] font-thai-title group-hover:text-[#8C2C1D] transition-colors">
              {language === 'th' ? 'เรือนรสไทย' : 'Ruen Ros Thai'}
            </span>
            <span className="text-[10px] sm:text-xs tracking-widest uppercase text-[#9C7A58] font-display font-medium -mt-1">
              Heritage Thai Cuisine
            </span>
          </div>
        </a>

        {/* Zone 2: 4 Clean Single-Line Text Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-[#5C4A3E]">
          <a
            href="#menu"
            className="hover:text-[#8C2C1D] transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
          >
            {language === 'th' ? 'เมนูอาหารชาววัง' : 'Royal Menus'}
          </a>
          <a
            href="#heritage"
            className="hover:text-[#8C2C1D] transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
          >
            {language === 'th' ? 'ตำรับและเรื่องเล่า' : 'Our Heritage'}
          </a>
          <a
            href="#reservation"
            onClick={(e) => {
              e.preventDefault();
              onOpenReservation();
            }}
            className="hover:text-[#8C2C1D] transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
          >
            {language === 'th' ? 'สำรองที่นั่ง' : 'Table Reservation'}
          </a>
          <a
            href="#location"
            className="hover:text-[#8C2C1D] transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8"
          >
            {language === 'th' ? 'ที่ตั้งและการติดต่อ' : 'Location & Hours'}
          </a>
        </nav>

        {/* Zone 3: 1 Primary Action + Utility Controls */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language Toggle Button */}
          <button
            onClick={onToggleLanguage}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[#6B5546] hover:bg-[#EFE9DF] border border-[#E7DFD3] transition-colors"
            title="Change Language"
          >
            <Globe className="w-3.5 h-3.5 text-[#8C2C1D]" />
            <span className="font-semibold uppercase">{language === 'th' ? 'EN' : 'TH'}</span>
          </button>

          {/* Table reservation quick button */}
          <button
            onClick={onOpenReservation}
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#4A3326] hover:text-[#8C2C1D] bg-[#F1ECE1] hover:bg-[#EAE2D3] border border-[#D9CFC1] rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Calendar className="w-4 h-4 text-[#8C2C1D]" />
            <span>{language === 'th' ? 'จองโต๊ะ' : 'Reserve'}</span>
          </button>

          {/* Primary Action: Shopping Cart Button */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium text-white bg-[#8C2C1D] hover:bg-[#722115] active:scale-[0.98] rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0"
            aria-label="Open Cart"
          >
            <ShoppingBag className="w-4 h-4 text-[#F5E6CC]" />
            <span>{language === 'th' ? 'สำรับอาหาร' : 'My Order'}</span>
            {cartCount > 0 && (
              <span className="flex items-center justify-center min-w-[20px] h-5 px-1.5 text-xs font-bold bg-[#D97706] text-white rounded-full tabular-nums">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
